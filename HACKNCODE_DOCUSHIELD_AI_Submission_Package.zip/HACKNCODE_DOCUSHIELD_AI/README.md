# DOCUSHIELD AI — HACKNCODE

AI-Powered Document Forensics & Contextual Intelligence System  
DataOps Innovation Hackathon 2026

## What this prototype does
- Accepts multiple PDF, PNG and JPG documents.
- Computes SHA-256 hashes for evidence identification.
- Extracts embedded text from text-based PDFs using PyMuPDF.
- Optionally extracts text from image uploads using Tesseract OCR.
- Extracts a small set of supported fields (name, DOB, document ID, address, amount, email).
- Compares extracted values across documents and flags conflicts for human review.
- Performs basic image screening and provides a downloadable JSON/TXT investigation dossier.

## Run locally
Python 3.10+ recommended.

```bash
python -m venv .venv
# Windows:
.venv\\Scripts\\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
streamlit run app/streamlit_app.py
```

Open the local URL shown by Streamlit (usually http://localhost:8501).

### Optional OCR setup
Install the Tesseract OCR engine separately for your operating system, then install `pytesseract` (included in requirements). Image uploads can then be OCR-processed. Scanned PDFs are not OCR-processed in this prototype.

## Demo workflow
1. Open the app.
2. Upload two or more related sample PDFs from `sample_data/`.
3. Click **Analyze submitted documents**.
4. Inspect extracted fields and SHA-256 identifiers.
5. Open **Findings & Correlation** to view conflicting values.
6. Open **Investigation Dossier** and download JSON/TXT outputs.

## Honest integration status
| Capability | Status |
|---|---|
| PDF embedded-text extraction | Implemented (local, PyMuPDF) |
| Image OCR | Optional, requires external Tesseract installation |
| Scanned PDF OCR | Not implemented |
| Structured field extraction | Implemented (regex prototype) |
| Cross-document comparison | Implemented (supported fields only) |
| Image screening | Basic heuristic only |
| LLM-based contextual reasoning | Not implemented |
| Signature verification | Not implemented |
| Issuer/database verification | Not implemented |
| PDF dossier export | Not implemented in this prototype; JSON/TXT dossier available |

## Safety and limitations
Use only synthetic or explicitly authorized documents. Findings are indicators for human review, not proof of fraud. OCR and regex extraction can be wrong or incomplete. Image recompression screening cannot establish manipulation. A qualified human must verify original documents and context.

## Team
- Parag Patel — Team Leader
- Dhruvi Dave — Team Member
- Dhruvansh Dave — Team Member

## Standards used as design references
ISO/IEC 27037, ISO/IEC 27042, NIST SP 800-86. No formal compliance claim is made.
